setwd("C:\\Users\\CYBORG\\Desktop\\it24100590LAB10")

observed_counts <- c(120, 95, 85, 100)

chisq.test(x = observed_counts)
